"""
Shendi–Atbara AI-Guided Exploration Framework — Python v3

Purpose
-------
Formation-level analog scoring + Monte Carlo petroleum-system assessment
with SSPI, RSSF, PPI, LCM, dynamic weights, risk decomposition, and
Kandaka-1 as optional blind-validation data.

Expected input
--------------
Preferred: Shendi_Atbara_Project_Master_Matrix.xlsx
Sheets:
- Formation_Features
- Analog_Formations
- Risk_Factors
- Kandaka1_Blind_Validation

You may also export these sheets as CSV and set USE_EXCEL=False.

Core principle
--------------
Do NOT train/calibrate the first run on Kandaka-1. Use Kandaka-1 only
for blind validation after predictions are generated.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import numpy as np
import pandas as pd


# ----------------------------
# Configuration
# ----------------------------

@dataclass
class ModelConfig:
    workbook_path: str = "Shendi_Atbara_Project_Master_Matrix_v1.xlsx"
    n_mc: int = 10_000
    random_seed: int = 42
    sigma_fraction_low: float = 0.25
    sigma_fraction_high: float = 0.35
    exclude_kandaka_from_training: bool = True
    target_basin: str = "Shendi–Atbara"
    target_formations: Tuple[str, ...] = ("Shendi Fm", "Mahmiya Fm", "Bagrawiya Fm")


NUMERIC_FEATURES = [
    "Age_Ma",
    "Grain_Size_mm",
    "Sorting_0_1",
    "Porosity_frac",
    "TOC_pct",
    "Fe_Oxide_0_1",
    "Paleocurrent_deg",
    "PPI_0_1",
    "LCM_0_1",
    "SSPI_0_1",
    "RSSF_0_1",
]

SIMILARITY_FEATURES = [
    "Age_Match_0_1",
    "Env_Match_0_1",
    "Lithology_Match_0_1",
    "Tectonic_Match_0_1",
    "SSPI_Match_0_1",
    "PPI_LCM_Match_0_1",
    "Data_Quality_0_1",
]


# ----------------------------
# Data loading and cleaning
# ----------------------------

def load_workbook_tables(config: ModelConfig) -> Dict[str, pd.DataFrame]:
    path = Path(config.workbook_path)
    if not path.exists():
        raise FileNotFoundError(
            f"Workbook not found: {path}. Upload it to Colab or update ModelConfig.workbook_path."
        )

    sheets = {
        "formation": "Formation_Features",
        "analog": "Analog_Formations",
        "risk": "Risk_Factors",
        "kandaka": "Kandaka1_Blind_Validation",
        "well": "Well_Data",
        "geophysics": "Geophysics",
        "source": "Source_Terrain_Matrix",
        "paleo": "PaleoClimate_PPI_LCM",
    }
    return {key: pd.read_excel(path, sheet_name=sheet) for key, sheet in sheets.items()}


def clean_numeric(df: pd.DataFrame, cols: Iterable[str]) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    return out


def confidence_to_quality(conf: str | float | int | None) -> float:
    if pd.isna(conf):
        return 0.35
    if isinstance(conf, (int, float)):
        return float(np.clip(conf, 0, 1))
    s = str(conf).strip().lower()
    mapping = {
        "low": 0.30,
        "medium": 0.55,
        "medium-high": 0.70,
        "high": 0.80,
        "very high": 0.95,
    }
    return mapping.get(s, 0.45)


# ----------------------------
# Formation analog scoring
# ----------------------------

def compute_formation_analog_scores(analog_df: pd.DataFrame) -> pd.DataFrame:
    df = clean_numeric(analog_df, SIMILARITY_FEATURES).copy()

    # Dynamic weights: quality affects final contribution, but not as a hard gate.
    base_weights = {
        "Age_Match_0_1": 0.12,
        "Env_Match_0_1": 0.20,
        "Lithology_Match_0_1": 0.18,
        "Tectonic_Match_0_1": 0.15,
        "SSPI_Match_0_1": 0.15,
        "PPI_LCM_Match_0_1": 0.12,
        "Data_Quality_0_1": 0.08,
    }
    available = [c for c in SIMILARITY_FEATURES if c in df.columns]
    weights = np.array([base_weights[c] for c in available], dtype=float)
    weights = weights / weights.sum()

    vals = df[available].fillna(0.5).to_numpy(dtype=float)
    raw = vals @ weights

    # penalize low data quality softly
    data_q = df.get("Data_Quality_0_1", pd.Series(0.5, index=df.index)).fillna(0.5).to_numpy(dtype=float)
    df["Formation_Analog_Score_v3"] = np.clip(raw * (0.70 + 0.30 * data_q), 0, 1)
    return df.sort_values("Formation_Analog_Score_v3", ascending=False)


# ----------------------------
# Petroleum probability model
# ----------------------------

def sigmoid(x: np.ndarray | float) -> np.ndarray | float:
    return 1 / (1 + np.exp(-x))


def risk_lookup(risk_df: pd.DataFrame) -> Dict[str, float]:
    r = clean_numeric(
        risk_df,
        ["Seal_Risk_0_1", "Timing_Risk_0_1", "Leakage_Risk_0_1", "Data_Gap_Risk_0_1", "Fault_Risk_0_1"],
    ).copy()
    risk_cols = ["Seal_Risk_0_1", "Timing_Risk_0_1", "Leakage_Risk_0_1", "Data_Gap_Risk_0_1", "Fault_Risk_0_1"]
    r["Overall_Risk_v3"] = r[risk_cols].mean(axis=1, skipna=True)
    return dict(zip(r["Formation"], r["Overall_Risk_v3"]))


def sample_feature(mu: float, rng: np.random.Generator, sigma_fraction: float, n: int, clip: Optional[Tuple[float, float]] = None) -> np.ndarray:
    if pd.isna(mu):
        mu = 0.5
    sigma = abs(mu) * sigma_fraction
    if sigma == 0:
        sigma = sigma_fraction
    x = rng.normal(mu, sigma, n)
    if clip is not None:
        x = np.clip(x, clip[0], clip[1])
    return x


def run_monte_carlo_for_formation(row: pd.Series, risk_value: float, config: ModelConfig) -> Dict[str, float]:
    rng = np.random.default_rng(config.random_seed + abs(hash(str(row.get("Formation", "")))) % 100_000)
    n = config.n_mc
    sigma_fraction = rng.uniform(config.sigma_fraction_low, config.sigma_fraction_high)

    # Sample normalized/probability-like variables.
    por = sample_feature(row.get("Porosity_frac", 0.18), rng, sigma_fraction, n, (0, 0.35))
    toc = sample_feature(row.get("TOC_pct", 1.5), rng, sigma_fraction, n, (0, 10))
    sorting = sample_feature(row.get("Sorting_0_1", 0.6), rng, sigma_fraction, n, (0, 1))
    fe = sample_feature(row.get("Fe_Oxide_0_1", 0.5), rng, sigma_fraction, n, (0, 1))
    ppi = sample_feature(row.get("PPI_0_1", 0.6), rng, sigma_fraction, n, (0, 1))
    lcm = sample_feature(row.get("LCM_0_1", 0.7), rng, sigma_fraction, n, (0, 1))
    sspi = sample_feature(row.get("SSPI_0_1", 0.65), rng, sigma_fraction, n, (0, 1))
    rssf = sample_feature(row.get("RSSF_0_1", 0.7), rng, sigma_fraction, n, (0, 1))
    risk = sample_feature(risk_value, rng, sigma_fraction, n, (0, 1))

    # Probabilistic components.
    # These are intentionally conservative for a frontier basin.
    p_source = sigmoid(-1.0 + 0.55 * toc + 0.90 * lcm + 0.50 * ppi - 0.65 * fe)
    p_reservoir = sigmoid(-0.85 + 7.0 * por + 1.25 * sorting + 0.85 * sspi - 0.35 * fe)
    p_trap = sigmoid(-0.60 + 0.90 * rssf + 0.75 * ppi - 1.25 * risk)
    p_total = p_source * p_reservoir * p_trap * (1 - risk)

    def summarize(x: np.ndarray, prefix: str) -> Dict[str, float]:
        return {
            f"{prefix}_mean": float(np.mean(x)),
            f"{prefix}_p025": float(np.quantile(x, 0.025)),
            f"{prefix}_p975": float(np.quantile(x, 0.975)),
            f"{prefix}_std": float(np.std(x, ddof=1)),
        }

    out = {
        "Basin": row.get("Basin"),
        "Formation": row.get("Formation"),
        "n_mc": n,
        "sigma_fraction_used": float(sigma_fraction),
        "risk_mean_input": float(risk_value),
    }
    out.update(summarize(p_source, "P_source"))
    out.update(summarize(p_reservoir, "P_reservoir"))
    out.update(summarize(p_trap, "P_trap"))
    out.update(summarize(1 - risk, "One_minus_Risk"))
    out.update(summarize(p_total, "P_petroleum"))
    out["P_petroleum_gt_0_3"] = float(np.mean(p_total > 0.30))
    out["P_petroleum_gt_0_5"] = float(np.mean(p_total > 0.50))
    return out


def run_petroleum_monte_carlo(formation_df: pd.DataFrame, risk_df: pd.DataFrame, config: ModelConfig) -> pd.DataFrame:
    f = clean_numeric(formation_df, NUMERIC_FEATURES).copy()
    risks = risk_lookup(risk_df)

    targets = f[
        (f["Basin"].eq(config.target_basin))
        & (f["Formation"].isin(config.target_formations))
    ].copy()

    results = []
    for _, row in targets.iterrows():
        rv = risks.get(row["Formation"], 0.50)
        results.append(run_monte_carlo_for_formation(row, rv, config))
    return pd.DataFrame(results)


# ----------------------------
# Blind validation scaffold
# ----------------------------

def blind_validation_summary(predictions: pd.DataFrame, kandaka_df: pd.DataFrame) -> pd.DataFrame:
    """Creates a prediction-vs-observation scaffold.
    This does NOT yet score exact success until formal target rules are defined.
    """
    k = kandaka_df[["Formation", "Lithology", "Environment", "Validation_Target", "Confidence"]].copy()
    merged = k.merge(predictions, on="Formation", how="left")
    merged["Validation_Status"] = np.where(merged["P_petroleum_mean"].notna(), "Ready for blind comparison", "No prediction")
    return merged


# ----------------------------
# Main runner
# ----------------------------

def main() -> None:
    config = ModelConfig()
    tables = load_workbook_tables(config)

    analog_scores = compute_formation_analog_scores(tables["analog"])
    mc_results = run_petroleum_monte_carlo(tables["formation"], tables["risk"], config)
    validation = blind_validation_summary(mc_results, tables["kandaka"])

    out_dir = Path("outputs")
    out_dir.mkdir(exist_ok=True)

    analog_scores.to_csv(out_dir / "formation_analog_scores_v3.csv", index=False)
    mc_results.to_csv(out_dir / "monte_carlo_results_v3.csv", index=False)
    validation.to_csv(out_dir / "kandaka_blind_validation_scaffold_v3.csv", index=False)

    print("\n=== Top Formation Analogs ===")
    print(analog_scores[[
        "Target_Formation", "Analog_Basin", "Analog_Formation", "Formation_Analog_Score_v3"
    ]].head(10).to_string(index=False))

    print("\n=== Monte Carlo v3 Results ===")
    cols = [
        "Formation", "P_source_mean", "P_reservoir_mean", "P_trap_mean",
        "One_minus_Risk_mean", "P_petroleum_mean", "P_petroleum_p025",
        "P_petroleum_p975", "P_petroleum_gt_0_3", "P_petroleum_gt_0_5"
    ]
    print(mc_results[cols].to_string(index=False))

    print("\nFiles written to ./outputs/")


if __name__ == "__main__":
    main()
