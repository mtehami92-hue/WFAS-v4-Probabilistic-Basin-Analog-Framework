
# ============================================================
# Data-Equity Filter / Minimum-Coverage Simulation v1
# For Shendi–Atbara CASZ/WCARS Formation Analog Model
#
# Purpose:
# 1) Quantify Data Coverage Score (DCS) per analog basin.
# 2) Test whether data-rich basins dominate WFAS.
# 3) Recompute WFAS under equalized feature coverage.
# 4) Produce Bias-Corrected / Equity-WFAS outputs.
#
# Required input:
#   Shendi_Atbara_Project_Master_Matrix_v4_WFAS_MC.xlsx
#
# Output:
#   outputs_data_equity/
#   Shendi_Atbara_Data_Equity_Filter_Report_v1.xlsx
# ============================================================

import os
import numpy as np
import pandas as pd

# ----------------------------
# CONFIG
# ----------------------------
MASTER_XLSX = "Shendi_Atbara_Project_Master_Matrix_v4_WFAS_MC.xlsx"
OUTDIR = "outputs_data_equity"
N_SIM = 5000
RANDOM_SEED = 2026

os.makedirs(OUTDIR, exist_ok=True)
rng = np.random.default_rng(RANDOM_SEED)

# ----------------------------
# LOAD
# ----------------------------
if not os.path.exists(MASTER_XLSX):
    raise FileNotFoundError(f"Missing workbook: {MASTER_XLSX}")

xls = pd.ExcelFile(MASTER_XLSX)
print("Available sheets:", xls.sheet_names)

def read_sheet_candidates(candidates):
    for s in candidates:
        if s in xls.sheet_names:
            return pd.read_excel(MASTER_XLSX, sheet_name=s), s
    return pd.DataFrame(), None

wfas, wfas_sheet = read_sheet_candidates([
    "WFAS_Formation_Analogs_v4",
    "WFAS_v4",
    "Top_Formation_Analogs_v4",
])

features, features_sheet = read_sheet_candidates([
    "Analog_Formations",
    "Formation_Features",
])

weights, weights_sheet = read_sheet_candidates([
    "WFAS_Weights_v4",
])

mc, mc_sheet = read_sheet_candidates([
    "Monte_Carlo_v4_LogOdds",
    "MonteCarlo_v4",
])

if wfas.empty:
    raise ValueError("No WFAS analog table found.")

print(f"Using WFAS sheet: {wfas_sheet}")
print(f"Using feature sheet: {features_sheet}")
print(f"Using weights sheet: {weights_sheet}")
print(f"Using MC sheet: {mc_sheet}")

# ----------------------------
# NORMALIZE COLUMN NAMES
# ----------------------------
def normalize_wfas_columns(df):
    rename = {}
    for c in df.columns:
        cl = str(c).strip().lower()
        if "target" in cl and "formation" in cl:
            rename[c] = "Target_Formation"
        elif "analog" in cl and "basin" in cl:
            rename[c] = "Analog_Basin"
        elif "analog" in cl and "formation" in cl:
            rename[c] = "Analog_Formation"
        elif "wfas" in cl:
            rename[c] = "WFAS_v4"
        elif "spatial" in cl:
            rename[c] = "Spatial_Support_0_1"
    return df.rename(columns=rename)

wfas = normalize_wfas_columns(wfas)

required = ["Target_Formation", "Analog_Basin", "Analog_Formation", "WFAS_v4"]
missing = [c for c in required if c not in wfas.columns]
if missing:
    raise ValueError(f"WFAS table missing columns: {missing}")

# ----------------------------
# FEATURE COVERAGE MODEL
# ----------------------------
# If a detailed feature table is available, infer feature counts.
# Otherwise use WFAS rows as minimum observable units.
feature_columns_core = [
    "Age_Score", "Lithology_Score", "Depositional_Env_Score",
    "Tectonic_Score", "Provenance_Score", "Paleoclimate_Score",
    "Reservoir_Score", "Source_Score", "Trap_Score",
    "Spatial_Support_0_1", "PPI", "LCM", "SSPI", "RSSF",
    "FeOx_modifier", "Clay_modifier", "Gravity_low_modifier"
]

coverage_records = []

if not features.empty and "Analog_Basin" in features.columns:
    fdf = features.copy()
    # Count non-null informative columns by basin
    candidate_cols = [c for c in fdf.columns if c not in ["Target_Formation", "Analog_Basin", "Analog_Formation", "Formation"]]
    for basin, g in fdf.groupby("Analog_Basin"):
        nonnull = g[candidate_cols].notna().sum().sum()
        n_rows = len(g)
        coverage_records.append({
            "Analog_Basin": basin,
            "Feature_Row_Count": n_rows,
            "NonNull_Feature_Cells": int(nonnull),
            "Coverage_Source": features_sheet
        })
else:
    # Proxy: use analog rows + available columns in WFAS table
    candidate_cols = [c for c in wfas.columns if c not in ["Target_Formation", "Analog_Basin", "Analog_Formation"]]
    for basin, g in wfas.groupby("Analog_Basin"):
        nonnull = g[candidate_cols].notna().sum().sum()
        n_rows = len(g)
        coverage_records.append({
            "Analog_Basin": basin,
            "Feature_Row_Count": n_rows,
            "NonNull_Feature_Cells": int(nonnull),
            "Coverage_Source": "WFAS_proxy"
        })

coverage = pd.DataFrame(coverage_records)

# Data Coverage Score: normalized by max coverage
coverage["DCS_row_based"] = coverage["Feature_Row_Count"] / max(coverage["Feature_Row_Count"].max(), 1)
coverage["DCS_cell_based"] = coverage["NonNull_Feature_Cells"] / max(coverage["NonNull_Feature_Cells"].max(), 1)

# Minimum coverage
N_min_rows = int(coverage["Feature_Row_Count"].min())
C_min_cells = int(coverage["NonNull_Feature_Cells"].min())

print("\n=== Data Coverage ===")
print(coverage)
print(f"\nN_min_rows = {N_min_rows}")
print(f"C_min_cells = {C_min_cells}")

# ----------------------------
# EQUITY-WFAS SIMULATION
# ----------------------------
# Equalize each analog basin to minimum number of analog rows.
# For each simulation, sample N_min_rows from each basin and recompute
# top target-formation WFAS statistics.
sim_records = []

basins = sorted(wfas["Analog_Basin"].dropna().unique())

for sim in range(N_SIM):
    sampled_parts = []
    for basin in basins:
        g = wfas[wfas["Analog_Basin"] == basin]
        if len(g) <= N_min_rows:
            sampled = g.copy()
        else:
            sampled = g.sample(n=N_min_rows, replace=False, random_state=int(rng.integers(0, 1e9)))
        sampled_parts.append(sampled)

    sampled_wfas = pd.concat(sampled_parts, ignore_index=True)

    # For each target formation, use best available analog score under equalized data.
    for formation, g in sampled_wfas.groupby("Target_Formation"):
        best = g.sort_values("WFAS_v4", ascending=False).iloc[0]
        sim_records.append({
            "Simulation": sim,
            "Target_Formation": formation,
            "Equity_Top_Basin": best["Analog_Basin"],
            "Equity_Top_Analog": best["Analog_Formation"],
            "Equity_WFAS": float(best["WFAS_v4"]),
            "Equity_Spatial_Support": float(best["Spatial_Support_0_1"]) if "Spatial_Support_0_1" in best.index else np.nan,
        })

sim_df = pd.DataFrame(sim_records)

equity_summary = (
    sim_df.groupby("Target_Formation")
    .agg(
        Equity_WFAS_mean=("Equity_WFAS", "mean"),
        Equity_WFAS_std=("Equity_WFAS", "std"),
        Equity_WFAS_p025=("Equity_WFAS", lambda x: np.percentile(x, 2.5)),
        Equity_WFAS_p975=("Equity_WFAS", lambda x: np.percentile(x, 97.5)),
        N_sim=("Equity_WFAS", "count"),
    )
    .reset_index()
)

# Most frequent top basin per target
top_basin_freq = (
    sim_df.groupby(["Target_Formation", "Equity_Top_Basin"])
    .size()
    .reset_index(name="Count")
)
top_basin_freq["Frequency"] = top_basin_freq.groupby("Target_Formation")["Count"].transform(lambda x: x / x.sum())
top_basin_freq = top_basin_freq.sort_values(["Target_Formation", "Frequency"], ascending=[True, False])

# ----------------------------
# ORIGINAL VS EQUITY COMPARISON
# ----------------------------
orig_top = (
    wfas.sort_values("WFAS_v4", ascending=False)
    .groupby("Target_Formation")
    .head(1)
    .copy()
)
orig_top = orig_top[["Target_Formation", "Analog_Basin", "Analog_Formation", "WFAS_v4"]]
orig_top = orig_top.rename(columns={
    "Analog_Basin": "Original_Top_Basin",
    "Analog_Formation": "Original_Top_Analog",
    "WFAS_v4": "Original_WFAS"
})

comparison = orig_top.merge(equity_summary, on="Target_Formation", how="left")
comparison["Delta_Equity_minus_Original"] = comparison["Equity_WFAS_mean"] - comparison["Original_WFAS"]
comparison["Abs_Delta"] = comparison["Delta_Equity_minus_Original"].abs()

# Bias risk classification
def classify_bias(delta_abs):
    if delta_abs >= 0.08:
        return "High data-coverage bias risk"
    elif delta_abs >= 0.04:
        return "Moderate data-coverage bias risk"
    else:
        return "Low data-coverage bias risk"

comparison["Bias_Risk_Class"] = comparison["Abs_Delta"].apply(classify_bias)

# ----------------------------
# BASIN-LEVEL EQUITY EFFECT
# ----------------------------
# How often each basin remains top after equalization.
basin_equity_strength = (
    sim_df.groupby("Equity_Top_Basin")
    .agg(
        Top_Count=("Equity_Top_Basin", "count"),
        Mean_Equity_WFAS=("Equity_WFAS", "mean"),
    )
    .reset_index()
    .rename(columns={"Equity_Top_Basin": "Analog_Basin"})
)
basin_equity_strength["Top_Frequency_All"] = basin_equity_strength["Top_Count"] / basin_equity_strength["Top_Count"].sum()

basin_equity_strength = basin_equity_strength.merge(
    coverage,
    on="Analog_Basin",
    how="left"
)

# ----------------------------
# OPTIONAL: Bias-corrected WFAS
# ----------------------------
# Conservative correction:
# Corrected_WFAS = WFAS / sqrt(DCS), clipped to [0,1]
# But we report it as diagnostic only, not as final replacement.
dcs_map = dict(zip(coverage["Analog_Basin"], coverage["DCS_cell_based"]))
wfas_corrected = wfas.copy()
wfas_corrected["DCS_cell_based"] = wfas_corrected["Analog_Basin"].map(dcs_map)
wfas_corrected["Bias_Corrected_WFAS_diag"] = (
    wfas_corrected["WFAS_v4"] / np.sqrt(wfas_corrected["DCS_cell_based"].clip(lower=0.25))
).clip(0, 1)

corrected_top = (
    wfas_corrected.sort_values("Bias_Corrected_WFAS_diag", ascending=False)
    .groupby("Target_Formation")
    .head(3)
    .copy()
)

# ----------------------------
# SAVE
# ----------------------------
out_xlsx = os.path.join(OUTDIR, "Shendi_Atbara_Data_Equity_Filter_Report_v1.xlsx")

with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
    coverage.to_excel(writer, sheet_name="Data_Coverage_Score", index=False)
    wfas.to_excel(writer, sheet_name="Original_WFAS_Input", index=False)
    sim_df.to_excel(writer, sheet_name="Equity_Simulation_Detail", index=False)
    equity_summary.to_excel(writer, sheet_name="Equity_WFAS_Summary", index=False)
    top_basin_freq.to_excel(writer, sheet_name="Top_Basin_Frequency", index=False)
    comparison.to_excel(writer, sheet_name="Original_vs_Equity", index=False)
    basin_equity_strength.to_excel(writer, sheet_name="Basin_Equity_Strength", index=False)
    wfas_corrected.to_excel(writer, sheet_name="Bias_Corrected_WFAS_All", index=False)
    corrected_top.to_excel(writer, sheet_name="Bias_Corrected_Top3", index=False)

coverage.to_csv(os.path.join(OUTDIR, "data_coverage_score.csv"), index=False)
comparison.to_csv(os.path.join(OUTDIR, "original_vs_equity_wfas.csv"), index=False)
top_basin_freq.to_csv(os.path.join(OUTDIR, "top_basin_frequency.csv"), index=False)

print("\n=== Original vs Equity WFAS ===")
print(comparison)

print("\n=== Top Basin Frequency After Equity Simulation ===")
print(top_basin_freq)

print("\n=== Basin Equity Strength ===")
print(basin_equity_strength)

print("\nSaved:")
print(out_xlsx)
print(OUTDIR)
