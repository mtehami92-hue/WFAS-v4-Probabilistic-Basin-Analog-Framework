"""
Shendi–Atbara / CASZ-WCARS Blind Calibration Test Runner v1

Purpose
-------
Reads the Blind Calibration Package workbook, scores BT1–BT3 after model outputs
are entered, and writes transparent calibration summaries.

Required input:
    Shendi_Atbara_Blind_Calibration_Package_v1.xlsx

Expected manually/model-filled columns:
    BT1_Analog_Recovery:
        Model_Top1_Prediction, Model_Top3_List, Role_Match_0_1 (optional)
    BT2_Role_Prediction:
        Model_P_source, Model_P_reservoir, Model_P_trap, Predicted_Role
    BT3_Kandaka_Validation:
        Observed_After_Reveal, Match_Score_0_1

Outputs:
    outputs_blind_tests/blind_test_summary.csv
    outputs_blind_tests/blind_test_detailed_scores.xlsx
"""

import os
from pathlib import Path
import numpy as np
import pandas as pd

INPUT_XLSX = "Shendi_Atbara_Blind_Calibration_Package_v1.xlsx"
OUTPUT_DIR = Path("outputs_blind_tests")
OUTPUT_DIR.mkdir(exist_ok=True)


def norm_text(x):
    if pd.isna(x):
        return ""
    return str(x).strip().lower()


def contains_expected(prediction, expected):
    p = norm_text(prediction)
    e = norm_text(expected)
    if not p or not e:
        return np.nan
    # compare key tokens rather than exact strings
    tokens = [t for t in e.replace("-", " ").replace("/", " ").split() if len(t) >= 4]
    if not tokens:
        return np.nan
    return float(any(t in p for t in tokens))


def classify_role(p_source, p_reservoir, p_trap):
    vals = {
        "Source-prone": p_source,
        "Reservoir-prone": p_reservoir,
        "Trap/seal-prone": p_trap,
    }
    if any(pd.isna(v) for v in vals.values()):
        return ""
    best = max(vals, key=vals.get)
    # mixed if top two are close
    ordered = sorted(vals.items(), key=lambda kv: kv[1], reverse=True)
    if ordered[0][1] - ordered[1][1] < 0.08:
        return "Mixed"
    return best


def role_match(predicted, observed):
    p = norm_text(predicted)
    o = norm_text(observed)
    if not p or not o:
        return np.nan
    groups = {
        "source": ["source", "lacustrine", "organic"],
        "reservoir": ["reservoir", "sand", "fluvial"],
        "seal": ["seal", "trap", "mudstone", "shale"],
        "mixed": ["mixed", "transitional"]
    }
    def tags(s):
        out = set()
        for k, toks in groups.items():
            if any(t in s for t in toks):
                out.add(k)
        return out
    pt, ot = tags(p), tags(o)
    if not pt or not ot:
        return float(p == o)
    return float(len(pt & ot) > 0)


def score_bt1(xlsx):
    df = pd.read_excel(xlsx, sheet_name="BT1_Analog_Recovery")
    df["Top1_Correct_calc"] = [contains_expected(p, e) for p, e in zip(df["Model_Top1_Prediction"], df["Expected_Closest_Analog_Group"])]
    df["Top3_Contains_calc"] = [contains_expected(p, e) for p, e in zip(df["Model_Top3_List"], df["Expected_Closest_Analog_Group"])]
    if "Role_Match_0_1" in df:
        role_score = pd.to_numeric(df["Role_Match_0_1"], errors="coerce")
    else:
        role_score = pd.Series(np.nan, index=df.index)
    metrics = {
        "BT1_Top1_Accuracy": float(np.nanmean(df["Top1_Correct_calc"])),
        "BT1_Top3_Accuracy": float(np.nanmean(df["Top3_Contains_calc"])),
        "BT1_Role_Accuracy": float(np.nanmean(role_score)),
        "BT1_N_Scored": int(np.sum(~pd.isna(df["Top1_Correct_calc"])))
    }
    return df, metrics


def score_bt2(xlsx):
    df = pd.read_excel(xlsx, sheet_name="BT2_Role_Prediction")
    for col in ["Model_P_source", "Model_P_reservoir", "Model_P_trap"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["Predicted_Role_calc"] = [classify_role(s, r, t) for s, r, t in zip(df["Model_P_source"], df["Model_P_reservoir"], df["Model_P_trap"])]
    pred = df["Predicted_Role"].where(df["Predicted_Role"].notna() & (df["Predicted_Role"].astype(str).str.len() > 0), df["Predicted_Role_calc"])
    observed = df["Observed_Role_Revealed"].where(df["Observed_Role_Revealed"].notna() & (df["Observed_Role_Revealed"].astype(str).str.len() > 0), df["Hidden_Observed_Role"])
    df["Role_Correct_calc"] = [role_match(p, o) for p, o in zip(pred, observed)]
    metrics = {
        "BT2_Role_Accuracy": float(np.nanmean(df["Role_Correct_calc"])),
        "BT2_N_Scored": int(np.sum(~pd.isna(df["Role_Correct_calc"])))
    }
    return df, metrics


def score_bt3(xlsx):
    df = pd.read_excel(xlsx, sheet_name="BT3_Kandaka_Validation")
    scores = pd.to_numeric(df["Match_Score_0_1"], errors="coerce")
    metrics = {
        "BT3_Kandaka_Match_Mean": float(np.nanmean(scores)),
        "BT3_N_Scored": int(np.sum(~pd.isna(scores)))
    }
    return df, metrics


def main():
    xlsx = Path(INPUT_XLSX)
    if not xlsx.exists():
        raise FileNotFoundError(f"Input workbook not found: {xlsx.resolve()}")

    bt1, m1 = score_bt1(xlsx)
    bt2, m2 = score_bt2(xlsx)
    bt3, m3 = score_bt3(xlsx)

    metrics = {**m1, **m2, **m3}
    summary = pd.DataFrame([{"Metric": k, "Value": v} for k, v in metrics.items()])
    summary_path = OUTPUT_DIR / "blind_test_summary.csv"
    summary.to_csv(summary_path, index=False)

    detailed_path = OUTPUT_DIR / "blind_test_detailed_scores.xlsx"
    with pd.ExcelWriter(detailed_path, engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Summary", index=False)
        bt1.to_excel(writer, sheet_name="BT1_Scored", index=False)
        bt2.to_excel(writer, sheet_name="BT2_Scored", index=False)
        bt3.to_excel(writer, sheet_name="BT3_Scored", index=False)

    print("=== Blind Test Summary ===")
    print(summary.to_string(index=False))
    print(f"\nSaved: {summary_path}")
    print(f"Saved: {detailed_path}")


if __name__ == "__main__":
    main()
