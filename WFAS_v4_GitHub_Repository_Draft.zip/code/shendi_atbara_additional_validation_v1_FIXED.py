
# ============================================================
# Shendi–Atbara Additional Validation Suite v1 FIXED
# Tests: Monte Carlo Convergence + Negative Control
# Fix: handles duplicate/ambiguous Risk_mean columns safely.
# Required: Shendi_Atbara_Project_Master_Matrix_v4_WFAS_MC.xlsx
# Output: outputs_additional_validation/
# ============================================================

import os
import numpy as np
import pandas as pd

MASTER_XLSX = "Shendi_Atbara_Project_Master_Matrix_v4_WFAS_MC.xlsx"
OUTDIR = "outputs_additional_validation"
RANDOM_SEED = 2026
os.makedirs(OUTDIR, exist_ok=True)
rng = np.random.default_rng(RANDOM_SEED)

if not os.path.exists(MASTER_XLSX):
    raise FileNotFoundError(f"Missing workbook: {MASTER_XLSX}")

xls = pd.ExcelFile(MASTER_XLSX)
print("Available sheets:", xls.sheet_names)

def read_sheet(candidates):
    for s in candidates:
        if s in xls.sheet_names:
            return pd.read_excel(MASTER_XLSX, sheet_name=s), s
    return pd.DataFrame(), None

mc, mc_sheet = read_sheet(["Monte_Carlo_v4_LogOdds", "MonteCarlo_v4"])
if mc.empty:
    raise ValueError("Missing Monte Carlo v4 sheet: Monte_Carlo_v4_LogOdds or MonteCarlo_v4")

print("Using MC sheet:", mc_sheet)

# Remove unnamed columns
mc = mc.loc[:, ~mc.columns.astype(str).str.startswith("Unnamed")].copy()

# Normalize columns, avoiding duplicate mapping
rename = {}
used_targets = set()
for c in mc.columns:
    cl = str(c).strip().lower()
    target = None
    if cl == "formation":
        target = "Formation"
    elif "analog" in cl and "wfas" in cl:
        target = "Analog_support_WFAS"
    elif "source" in cl and "mean" in cl:
        target = "P_source_mean"
    elif "reservoir" in cl and "mean" in cl:
        target = "P_reservoir_mean"
    elif "trap" in cl and "mean" in cl:
        target = "P_trap_mean"
    elif cl == "risk_mean" or ("risk" in cl and "mean" in cl and "petroleum" not in cl):
        target = "Risk_mean"
    elif "petroleum" in cl and "mean" in cl:
        target = "P_petroleum_mean"

    if target is not None and target not in used_targets:
        rename[c] = target
        used_targets.add(target)

mc = mc.rename(columns=rename)

# Drop duplicate column names after renaming
mc = mc.loc[:, ~mc.columns.duplicated()].copy()

required = ["Formation","Analog_support_WFAS","P_source_mean","P_reservoir_mean","P_trap_mean","Risk_mean"]
missing = [c for c in required if c not in mc.columns]
if missing:
    raise ValueError(f"Missing required columns: {missing}\nColumns found: {mc.columns.tolist()}")

# Keep only valid formation rows
mc = mc[mc["Formation"].notna()].copy()
mc = mc[~mc["Formation"].astype(str).str.contains("Calibration", case=False, na=False)].copy()

# Ensure numeric columns
for c in required[1:]:
    mc[c] = pd.to_numeric(mc[c], errors="coerce")
mc = mc.dropna(subset=required).copy()

def scalar(row, col):
    v = row[col]
    if isinstance(v, pd.Series):
        v = v.iloc[0]
    return float(v)

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def logit(p, eps=1e-6):
    p = np.clip(p, eps, 1 - eps)
    return np.log(p / (1 - p))

WEIGHTS = {"analog":0.22, "source":0.22, "reservoir":0.20, "trap":0.22, "risk":0.14}

def predict(analog, source, reservoir, trap, risk):
    z = (
        WEIGHTS["analog"] * logit(analog)
        + WEIGHTS["source"] * logit(source)
        + WEIGHTS["reservoir"] * logit(reservoir)
        + WEIGHTS["trap"] * logit(trap)
        - WEIGHTS["risk"] * logit(risk)
    )
    return sigmoid(z)

# ============================================================
# 1) Monte Carlo Convergence Test
# ============================================================
N_LEVELS = [1000, 5000, 10000, 50000]
REPEATS = 10
SIGMA_FRAC = {
    "Analog_support_WFAS": 0.08,
    "P_source_mean": 0.18,
    "P_reservoir_mean": 0.18,
    "P_trap_mean": 0.20,
    "Risk_mean": 0.20,
}

conv = []
for _, row in mc.iterrows():
    formation = str(row["Formation"])
    mu_a = scalar(row, "Analog_support_WFAS")
    mu_s = scalar(row, "P_source_mean")
    mu_r = scalar(row, "P_reservoir_mean")
    mu_t = scalar(row, "P_trap_mean")
    mu_risk = scalar(row, "Risk_mean")

    for N in N_LEVELS:
        for rep in range(REPEATS):
            a = np.clip(rng.normal(mu_a, max(0.01, mu_a*SIGMA_FRAC["Analog_support_WFAS"]), N), 0.01, 0.99)
            s = np.clip(rng.normal(mu_s, max(0.01, mu_s*SIGMA_FRAC["P_source_mean"]), N), 0.01, 0.99)
            r = np.clip(rng.normal(mu_r, max(0.01, mu_r*SIGMA_FRAC["P_reservoir_mean"]), N), 0.01, 0.99)
            t = np.clip(rng.normal(mu_t, max(0.01, mu_t*SIGMA_FRAC["P_trap_mean"]), N), 0.01, 0.99)
            risk = np.clip(rng.normal(mu_risk, max(0.01, mu_risk*SIGMA_FRAC["Risk_mean"]), N), 0.01, 0.99)
            p = predict(a, s, r, t, risk)
            conv.append({
                "Formation": formation, "N_MC": N, "Repeat": rep,
                "P_mean": float(np.mean(p)),
                "P_std": float(np.std(p)),
                "P_p025": float(np.percentile(p, 2.5)),
                "P_p975": float(np.percentile(p, 97.5)),
                "P_gt_0_5": float(np.mean(p > 0.5))
            })

conv_df = pd.DataFrame(conv)
conv_summary = conv_df.groupby(["Formation","N_MC"]).agg(
    Mean_P=("P_mean","mean"),
    SD_of_Mean_P=("P_mean","std"),
    Mean_P_std=("P_std","mean"),
    Mean_P_p025=("P_p025","mean"),
    Mean_P_p975=("P_p975","mean"),
    Mean_P_gt_0_5=("P_gt_0_5","mean")
).reset_index()

ref = conv_summary[conv_summary["N_MC"] == 50000][["Formation","Mean_P"]].rename(columns={"Mean_P":"Mean_P_ref_50000"})
conv_summary = conv_summary.merge(ref, on="Formation", how="left")
conv_summary["Abs_Delta_vs_50000"] = (conv_summary["Mean_P"] - conv_summary["Mean_P_ref_50000"]).abs()

# ============================================================
# 2) Negative Control Test
# ============================================================
neg = pd.DataFrame([
    ["NC1_NonRift_Marine_Carbonate",0.25,0.35,0.45,0.30,0.70,"Low"],
    ["NC2_Volcanic_Shield_Basalt_Dominated",0.18,0.15,0.25,0.25,0.82,"Very Low"],
    ["NC3_Crystalline_Basement_No_Basin",0.10,0.08,0.12,0.15,0.90,"Very Low"],
    ["NC4_OverOxidized_Shallow_Fluvial_No_Seal",0.38,0.20,0.62,0.25,0.78,"Low"],
    ["NC5_Random_LowCoherence_Analog",0.32,0.30,0.30,0.30,0.75,"Low"],
], columns=["Negative_Control","Analog_support_WFAS","P_source_mean","P_reservoir_mean","P_trap_mean","Risk_mean","Expected"])

neg["P_petroleum_negative_control"] = predict(
    neg["Analog_support_WFAS"].values,
    neg["P_source_mean"].values,
    neg["P_reservoir_mean"].values,
    neg["P_trap_mean"].values,
    neg["Risk_mean"].values,
)
neg["False_Positive_at_0_5"] = neg["P_petroleum_negative_control"] >= 0.5
neg["Pass_Negative_Control"] = ~neg["False_Positive_at_0_5"]

neg_summary = pd.DataFrame([{
    "N_negative_controls": len(neg),
    "False_Positive_Count_at_0_5": int(neg["False_Positive_at_0_5"].sum()),
    "False_Positive_Rate_at_0_5": float(neg["False_Positive_at_0_5"].mean()),
    "Pass_Rate": float(neg["Pass_Negative_Control"].mean()),
    "Max_Negative_Control_P": float(neg["P_petroleum_negative_control"].max()),
}])

# Random negative stress
N_RANDOM = 5000
rp = predict(
    rng.uniform(0.05,0.45,N_RANDOM),
    rng.uniform(0.05,0.45,N_RANDOM),
    rng.uniform(0.05,0.65,N_RANDOM),
    rng.uniform(0.05,0.45,N_RANDOM),
    rng.uniform(0.60,0.95,N_RANDOM),
)
rand_neg_summary = pd.DataFrame([{
    "N_random_negative_controls": N_RANDOM,
    "Mean_P": float(np.mean(rp)),
    "P_p025": float(np.percentile(rp,2.5)),
    "P_p975": float(np.percentile(rp,97.5)),
    "False_Positive_Rate_at_0_5": float(np.mean(rp >= 0.5)),
    "False_Positive_Rate_at_0_7": float(np.mean(rp >= 0.7)),
    "Max_P": float(np.max(rp)),
}])

# Save
out_xlsx = os.path.join(OUTDIR, "Shendi_Atbara_Additional_Validation_Report_v1_FIXED.xlsx")
with pd.ExcelWriter(out_xlsx, engine="openpyxl") as writer:
    mc.to_excel(writer, sheet_name="Input_MC_v4_cleaned", index=False)
    conv_df.to_excel(writer, sheet_name="MC_Convergence_Detail", index=False)
    conv_summary.to_excel(writer, sheet_name="MC_Convergence_Summary", index=False)
    neg.to_excel(writer, sheet_name="Negative_Control_Results", index=False)
    neg_summary.to_excel(writer, sheet_name="Negative_Control_Summary", index=False)
    rand_neg_summary.to_excel(writer, sheet_name="Random_Negative_Summary", index=False)

conv_summary.to_csv(os.path.join(OUTDIR, "mc_convergence_summary_FIXED.csv"), index=False)
neg.to_csv(os.path.join(OUTDIR, "negative_control_results_FIXED.csv"), index=False)
neg_summary.to_csv(os.path.join(OUTDIR, "negative_control_summary_FIXED.csv"), index=False)
rand_neg_summary.to_csv(os.path.join(OUTDIR, "random_negative_summary_FIXED.csv"), index=False)

print("\n=== Monte Carlo Convergence Summary ===")
print(conv_summary)
print("\n=== Negative Control Results ===")
print(neg[["Negative_Control","P_petroleum_negative_control","False_Positive_at_0_5","Pass_Negative_Control"]])
print("\n=== Negative Control Summary ===")
print(neg_summary)
print("\n=== Random Negative Control Summary ===")
print(rand_neg_summary)
print("\nSaved:", out_xlsx)
