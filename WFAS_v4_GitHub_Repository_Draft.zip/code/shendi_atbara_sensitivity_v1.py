# ============================================================
# Shendi–Atbara Model Sensitivity Analysis v1
# Scenario ablation + weight perturbation + rank stability
# ------------------------------------------------------------
# Required input:
#   Shendi_Atbara_Project_Master_Matrix_v4_Spatial.xlsx
# Optional:
#   outputs_v4/*.csv from shendi_atbara_model_v4_wfas_mc.py
# Outputs:
#   outputs_sensitivity/sensitivity_scenarios.csv
#   outputs_sensitivity/sensitivity_rank_stability.csv
#   outputs_sensitivity/sensitivity_weight_perturbation.csv
#   outputs_sensitivity/Shendi_Atbara_Sensitivity_Report_v1.xlsx
# ============================================================

import os
import numpy as np
import pandas as pd

MASTER_XLSX = "Shendi_Atbara_Project_Master_Matrix_v4_Spatial.xlsx"
OUTPUT_DIR = "outputs_sensitivity"
N_MC = 10000
RANDOM_SEED = 123
os.makedirs(OUTPUT_DIR, exist_ok=True)
np.random.seed(RANDOM_SEED)

# -----------------------------
# Helpers
# -----------------------------
def clip01(x):
    return np.clip(x, 1e-4, 1 - 1e-4)

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -50, 50)))

def logit(p):
    p = clip01(p)
    return np.log(p/(1-p))

def beta_sample_from_mean(mean, cv=0.28, size=1):
    mean = float(np.nan_to_num(mean, nan=0.5))
    mean = float(clip01(mean))
    var = (cv*mean)**2
    max_var = mean*(1-mean)*0.95
    var = min(var, max_var)
    if var <= 1e-8:
        return np.full(size, mean)
    common = mean*(1-mean)/var - 1
    a = max(mean*common, 0.5)
    b = max((1-mean)*common, 0.5)
    return np.random.beta(a,b,size=size)

def norm01(series):
    s = pd.to_numeric(series, errors='coerce')
    if s.notna().sum() == 0:
        return pd.Series(np.nan, index=series.index)
    mn, mx = s.min(), s.max()
    if abs(mx-mn) < 1e-12:
        return pd.Series(0.5, index=series.index)
    return (s-mn)/(mx-mn)

def safe_num(x, default=0.5):
    try:
        if pd.isna(x):
            return default
        return float(x)
    except Exception:
        return default

# -----------------------------
# Load master workbook
# -----------------------------
if not os.path.exists(MASTER_XLSX):
    raise FileNotFoundError(f"Missing {MASTER_XLSX}. Place it beside this script.")

xl = pd.ExcelFile(MASTER_XLSX)
sheets = {s: pd.read_excel(MASTER_XLSX, sheet_name=s) for s in xl.sheet_names}
formation_df = sheets['Formation_Features'].copy()
analog_df = sheets['Analog_Formations'].copy()
risk_df = sheets['Risk_Factors'].copy()
formation_spatial = sheets.get('Formation_Spatial_Modifiers', pd.DataFrame()).copy()

WFAS_WEIGHTS_BASE = {
    'Age_Match_0_1': 0.18,
    'Env_Match_0_1': 0.18,
    'Lithology_Match_0_1': 0.16,
    'SSPI_Match_0_1': 0.14,
    'PPI_LCM_Match_0_1': 0.10,
    'Tectonic_Match_0_1': 0.09,
    'Data_Quality_0_1': 0.08,
}
SPATIAL_WEIGHT_BASE = 0.07
LOGIT_WEIGHTS_BASE = {
    'source': 0.35,
    'reservoir': 0.30,
    'trap': 0.25,
    'analog': 0.15,
    'risk': 0.40,
}

SCENARIOS = [
    {'Scenario':'Baseline_v4', 'Description':'Full model with WFAS + ASTER + TOPEX + risk decomposition', 'remove':[]},
    {'Scenario':'No_Spatial_All', 'Description':'Remove all spatial support from ASTER/TOPEX', 'remove':['spatial']},
    {'Scenario':'No_TOPEX_Gravity', 'Description':'Remove gravity-low and gravity-gradient constraints', 'remove':['gravity']},
    {'Scenario':'No_ASTER', 'Description':'Remove FeOx, clay, and ferrous remote-sensing constraints', 'remove':['aster']},
    {'Scenario':'No_WFAS_Analog', 'Description':'Set formation analog support to neutral 0.5', 'remove':['analog']},
    {'Scenario':'No_Risk_Decomposition', 'Description':'Set risk to neutral 0.5 and remove spatial risk adjustment', 'remove':['risk']},
    {'Scenario':'No_Paleoclimate_PPI_LCM', 'Description':'Neutralize PPI and LCM terms', 'remove':['ppi_lcm']},
    {'Scenario':'No_Provenance_SSPI_RSSF', 'Description':'Neutralize sediment-source/provenance terms', 'remove':['provenance']},
    {'Scenario':'No_Reservoir_PorositySorting', 'Description':'Neutralize sorting and porosity constraints', 'remove':['reservoir_quality']},
    {'Scenario':'Risk_Stress_High', 'Description':'Increase all risk components by +0.15', 'remove':['risk_high']},
    {'Scenario':'Risk_Stress_Low', 'Description':'Decrease all risk components by -0.15', 'remove':['risk_low']},
]

def build_spatial(remove):
    fs = formation_spatial.copy()
    # fallback rows if missing
    if fs.empty:
        fs = pd.DataFrame({'Formation':['Bagrawiya Fm','Mahmiya Fm','Shendi Fm'],
                           'FeOx_modifier':[0.5,0.5,0.5], 'Clay_modifier':[0.5,0.5,0.5],
                           'Ferrous_modifier':[0.5,0.5,0.5], 'Gravity_low_modifier':[0.5,0.5,0.5],
                           'Gravity_gradient_modifier':[0.5,0.5,0.5]})
    for col in ['FeOx_modifier','Clay_modifier','Ferrous_modifier','Gravity_low_modifier','Gravity_gradient_modifier']:
        if col not in fs.columns:
            fs[col] = 0.5
        fs[col] = pd.to_numeric(fs[col], errors='coerce').fillna(0.5)
    if 'spatial' in remove:
        for col in ['FeOx_modifier','Clay_modifier','Ferrous_modifier','Gravity_low_modifier','Gravity_gradient_modifier']:
            fs[col] = 0.5
    if 'aster' in remove:
        for col in ['FeOx_modifier','Clay_modifier','Ferrous_modifier']:
            fs[col] = 0.5
    if 'gravity' in remove:
        for col in ['Gravity_low_modifier','Gravity_gradient_modifier']:
            fs[col] = 0.5
    fs['FeOx_norm'] = norm01(fs['FeOx_modifier']).fillna(0.5)
    fs['Clay_norm'] = norm01(fs['Clay_modifier']).fillna(0.5)
    fs['GravityLow_norm'] = norm01(fs['Gravity_low_modifier']).fillna(0.5)
    fs['GravityGradient_norm'] = norm01(fs['Gravity_gradient_modifier']).fillna(0.5)
    fs['Spatial_Support_0_1'] = (0.30*fs['FeOx_norm'] + 0.25*fs['Clay_norm'] + 0.35*fs['GravityLow_norm'] + 0.10*(1-fs['GravityGradient_norm'])).clip(0,1)
    if 'spatial' in remove:
        fs['Spatial_Support_0_1'] = 0.5
    return fs

def compute_model(remove=None, wfas_weights=None, spatial_weight=None, logit_weights=None, scenario='Baseline'):
    remove = remove or []
    wfas_weights = wfas_weights or WFAS_WEIGHTS_BASE.copy()
    spatial_weight = SPATIAL_WEIGHT_BASE if spatial_weight is None else spatial_weight
    logit_weights = logit_weights or LOGIT_WEIGHTS_BASE.copy()
    fs = build_spatial(remove)

    analog = analog_df.copy()
    for col in WFAS_WEIGHTS_BASE:
        if col not in analog.columns:
            analog[col] = 0.5
        analog[col] = pd.to_numeric(analog[col], errors='coerce').fillna(0.5).clip(0,1)
    analog = analog.merge(fs[['Formation','Spatial_Support_0_1']], how='left', left_on='Target_Formation', right_on='Formation')
    analog['Spatial_Support_0_1'] = analog['Spatial_Support_0_1'].fillna(0.5)
    analog['WFAS_v4'] = 0.0
    for col,w in wfas_weights.items():
        analog['WFAS_v4'] += w*analog[col]
    analog['WFAS_v4'] += spatial_weight*analog['Spatial_Support_0_1']
    if 'analog' in remove:
        analog['WFAS_v4'] = 0.5
    analog['WFAS_v4'] = analog['WFAS_v4'].clip(0,1)

    risk = risk_df.copy()
    for c in ['Seal_Risk_0_1','Timing_Risk_0_1','Leakage_Risk_0_1','Data_Gap_Risk_0_1','Fault_Risk_0_1']:
        if c not in risk.columns:
            risk[c] = 0.5
        risk[c] = pd.to_numeric(risk[c], errors='coerce').fillna(0.5).clip(0,1)
    risk = risk.merge(fs[['Formation','GravityGradient_norm','GravityLow_norm','Clay_norm','FeOx_norm']], on='Formation', how='left')
    for c in ['GravityGradient_norm','GravityLow_norm','Clay_norm','FeOx_norm']:
        risk[c] = risk[c].fillna(0.5)

    if 'risk' in remove:
        for c in ['Seal_Risk_v4','Timing_Risk_v4','Leakage_Risk_v4','Data_Gap_Risk_v4','Fault_Risk_v4','Overall_Risk_v4']:
            risk[c] = 0.5
    else:
        risk['Seal_Risk_v4'] = (risk['Seal_Risk_0_1'] - 0.08*risk['Clay_norm'] + 0.03*risk['FeOx_norm']).clip(0,1)
        risk['Timing_Risk_v4'] = (risk['Timing_Risk_0_1'] - 0.06*risk['GravityLow_norm']).clip(0,1)
        risk['Leakage_Risk_v4'] = (risk['Leakage_Risk_0_1'] + 0.10*risk['GravityGradient_norm']).clip(0,1)
        risk['Data_Gap_Risk_v4'] = risk['Data_Gap_Risk_0_1'].clip(0,1)
        risk['Fault_Risk_v4'] = (risk['Fault_Risk_0_1'] + 0.12*risk['GravityGradient_norm']).clip(0,1)
        if 'risk_high' in remove:
            for c in ['Seal_Risk_v4','Timing_Risk_v4','Leakage_Risk_v4','Data_Gap_Risk_v4','Fault_Risk_v4']:
                risk[c] = (risk[c] + 0.15).clip(0,1)
        if 'risk_low' in remove:
            for c in ['Seal_Risk_v4','Timing_Risk_v4','Leakage_Risk_v4','Data_Gap_Risk_v4','Fault_Risk_v4']:
                risk[c] = (risk[c] - 0.15).clip(0,1)
        risk['Overall_Risk_v4'] = (0.25*risk['Seal_Risk_v4'] + 0.20*risk['Timing_Risk_v4'] + 0.25*risk['Leakage_Risk_v4'] + 0.15*risk['Data_Gap_Risk_v4'] + 0.15*risk['Fault_Risk_v4']).clip(0,1)

    target_forms = formation_df[formation_df['Basin'].astype(str).str.contains('Shendi', case=False, na=False)].copy()
    if target_forms.empty:
        target_forms = formation_df[formation_df['Formation'].isin(risk['Formation'].unique())].copy()
    rows = []
    for _, frow in target_forms.iterrows():
        formation = frow['Formation']
        rr = risk[risk['Formation'].eq(formation)]
        overall_risk = safe_num(rr.iloc[0]['Overall_Risk_v4'],0.5) if not rr.empty else 0.5
        seal_risk = safe_num(rr.iloc[0]['Seal_Risk_v4'],0.5) if not rr.empty else 0.5
        leakage_risk = safe_num(rr.iloc[0]['Leakage_Risk_v4'],0.5) if not rr.empty else 0.5
        fault_risk = safe_num(rr.iloc[0]['Fault_Risk_v4'],0.5) if not rr.empty else 0.5
        arows = analog[analog['Target_Formation'].eq(formation)]
        analog_support = float(arows['WFAS_v4'].max()) if not arows.empty else 0.5

        ppi = safe_num(frow.get('PPI_0_1',np.nan),0.55)
        lcm = safe_num(frow.get('LCM_0_1',np.nan),0.55)
        sspi = safe_num(frow.get('SSPI_0_1',np.nan),0.55)
        rssf = safe_num(frow.get('RSSF_0_1',np.nan),0.55)
        sorting = safe_num(frow.get('Sorting_0_1',np.nan),0.55)
        poro = safe_num(frow.get('Porosity_frac',np.nan),0.15)
        toc = safe_num(frow.get('TOC_pct',np.nan),1.0)
        if 'ppi_lcm' in remove:
            ppi = 0.5; lcm = 0.5
        if 'provenance' in remove:
            sspi = 0.5; rssf = 0.5
        if 'reservoir_quality' in remove:
            sorting = 0.5; poro = 0.15

        fsrow = fs[fs['Formation'].eq(formation)]
        if fsrow.empty:
            spatial_source = spatial_res = spatial_trap = 0.5
        else:
            ff = fsrow.iloc[0]
            spatial_source = float(0.55*ff['GravityLow_norm'] + 0.45*ff['Clay_norm'])
            spatial_res = float(0.45*ff['FeOx_norm'] + 0.35*(1-ff['Clay_norm']) + 0.20*sspi)
            spatial_trap = float(0.50*(1-ff['GravityGradient_norm']) + 0.50*ff['GravityLow_norm'])
        if 'spatial' in remove:
            spatial_source = spatial_res = spatial_trap = 0.5

        p_source_mu = clip01(0.20 + 0.22*lcm + 0.18*ppi + 0.16*spatial_source + 0.12*min(toc/3.0,1) + 0.12*analog_support)
        p_res_mu = clip01(0.18 + 0.20*sorting + 0.16*sspi + 0.12*rssf + 0.18*min(poro/0.25,1) + 0.16*spatial_res)
        p_trap_mu = clip01(0.22 + 0.20*analog_support + 0.18*spatial_trap + 0.16*(1-fault_risk) + 0.12*(1-leakage_risk) + 0.12*(1-seal_risk))

        p_source = beta_sample_from_mean(p_source_mu, cv=0.30, size=N_MC)
        p_res = beta_sample_from_mean(p_res_mu, cv=0.28, size=N_MC)
        p_trap = beta_sample_from_mean(p_trap_mu, cv=0.30, size=N_MC)
        p_analog = beta_sample_from_mean(analog_support, cv=0.18, size=N_MC)
        p_risk = beta_sample_from_mean(overall_risk, cv=0.25, size=N_MC)
        score = (logit_weights['source']*logit(p_source) + logit_weights['reservoir']*logit(p_res) + logit_weights['trap']*logit(p_trap) + logit_weights['analog']*logit(p_analog) - logit_weights['risk']*logit(p_risk))
        p_petroleum = sigmoid(score)
        rows.append({'Scenario':scenario,'Formation':formation,'Analog_support_WFAS':analog_support,
                     'P_source_mean':float(np.mean(p_source)), 'P_reservoir_mean':float(np.mean(p_res)),
                     'P_trap_mean':float(np.mean(p_trap)), 'Risk_mean':float(np.mean(p_risk)),
                     'P_petroleum_mean':float(np.mean(p_petroleum)),
                     'P_petroleum_p025':float(np.percentile(p_petroleum,2.5)),
                     'P_petroleum_p500':float(np.percentile(p_petroleum,50)),
                     'P_petroleum_p975':float(np.percentile(p_petroleum,97.5)),
                     'P_petroleum_gt_0_5':float(np.mean(p_petroleum>0.5))})
    return pd.DataFrame(rows)

# -----------------------------
# Scenario ablation tests
# -----------------------------
all_scenario_rows = []
for sc in SCENARIOS:
    np.random.seed(RANDOM_SEED)
    df = compute_model(remove=sc['remove'], scenario=sc['Scenario'])
    df['Description'] = sc['Description']
    all_scenario_rows.append(df)
scenarios_df = pd.concat(all_scenario_rows, ignore_index=True)

baseline = scenarios_df[scenarios_df['Scenario'].eq('Baseline_v4')][['Formation','P_petroleum_mean']].rename(columns={'P_petroleum_mean':'Baseline_P'})
scenarios_df = scenarios_df.merge(baseline, on='Formation', how='left')
scenarios_df['Delta_vs_Baseline'] = scenarios_df['P_petroleum_mean'] - scenarios_df['Baseline_P']
scenarios_df['Abs_Delta_vs_Baseline'] = scenarios_df['Delta_vs_Baseline'].abs()
scenarios_df.to_csv(os.path.join(OUTPUT_DIR,'sensitivity_scenarios.csv'), index=False)

# Rank stability
rank_df = scenarios_df.copy()
rank_df['Rank_in_Scenario'] = rank_df.groupby('Scenario')['P_petroleum_mean'].rank(ascending=False, method='min')
rank_stability = rank_df.pivot_table(index='Formation', columns='Scenario', values='Rank_in_Scenario', aggfunc='first').reset_index()
rank_stability.to_csv(os.path.join(OUTPUT_DIR,'sensitivity_rank_stability.csv'), index=False)

# -----------------------------
# Weight perturbation: +/- 20% and normalized WFAS weights
# -----------------------------
pert_rows = []
weight_keys = list(WFAS_WEIGHTS_BASE.keys()) + ['Spatial_Support_0_1'] + list(LOGIT_WEIGHTS_BASE.keys())
for key in weight_keys:
    for mult in [0.8, 1.2]:
        wfas = WFAS_WEIGHTS_BASE.copy()
        sw = SPATIAL_WEIGHT_BASE
        lw = LOGIT_WEIGHTS_BASE.copy()
        if key in wfas:
            wfas[key] *= mult
            # keep total comparable: normalize geological WFAS weights back to base sum excluding spatial
            total_base = sum(WFAS_WEIGHTS_BASE.values())
            total_new = sum(wfas.values())
            for k in wfas:
                wfas[k] *= total_base/total_new
        elif key == 'Spatial_Support_0_1':
            sw *= mult
        elif key in lw:
            lw[key] *= mult
        np.random.seed(RANDOM_SEED)
        df = compute_model(wfas_weights=wfas, spatial_weight=sw, logit_weights=lw, scenario=f'{key}_x{mult}')
        df['Perturbed_Parameter'] = key
        df['Multiplier'] = mult
        pert_rows.append(df)
pert_df = pd.concat(pert_rows, ignore_index=True).merge(baseline, on='Formation', how='left')
pert_df['Delta_vs_Baseline'] = pert_df['P_petroleum_mean'] - pert_df['Baseline_P']
pert_df['Abs_Delta_vs_Baseline'] = pert_df['Delta_vs_Baseline'].abs()
pert_df.to_csv(os.path.join(OUTPUT_DIR,'sensitivity_weight_perturbation.csv'), index=False)

# Parameter importance summary
importance_scenarios = scenarios_df[~scenarios_df['Scenario'].eq('Baseline_v4')].groupby('Scenario', as_index=False).agg(
    Mean_Abs_Delta=('Abs_Delta_vs_Baseline','mean'),
    Max_Abs_Delta=('Abs_Delta_vs_Baseline','max'),
    Mean_Delta=('Delta_vs_Baseline','mean')
).sort_values('Mean_Abs_Delta', ascending=False)
importance_weights = pert_df.groupby('Perturbed_Parameter', as_index=False).agg(
    Mean_Abs_Delta=('Abs_Delta_vs_Baseline','mean'),
    Max_Abs_Delta=('Abs_Delta_vs_Baseline','max')
).sort_values('Mean_Abs_Delta', ascending=False)

# Workbook report
out_xlsx = os.path.join(OUTPUT_DIR,'Shendi_Atbara_Sensitivity_Report_v1.xlsx')
with pd.ExcelWriter(out_xlsx, engine='openpyxl') as writer:
    pd.DataFrame(SCENARIOS).to_excel(writer, sheet_name='Scenario_Definitions', index=False)
    scenarios_df.to_excel(writer, sheet_name='Scenario_Results', index=False)
    importance_scenarios.to_excel(writer, sheet_name='Ablation_Importance', index=False)
    rank_stability.to_excel(writer, sheet_name='Rank_Stability', index=False)
    pert_df.to_excel(writer, sheet_name='Weight_Perturbation', index=False)
    importance_weights.to_excel(writer, sheet_name='Weight_Importance', index=False)

print('\n=== Sensitivity Scenario Importance ===')
print(importance_scenarios.to_string(index=False))
print('\n=== Weight Perturbation Importance ===')
print(importance_weights.to_string(index=False))
print('\nSaved outputs to:', OUTPUT_DIR)
print('Workbook:', out_xlsx)
