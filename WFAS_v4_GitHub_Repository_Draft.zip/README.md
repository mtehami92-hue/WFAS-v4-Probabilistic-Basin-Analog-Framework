# WFAS-v4 Shendi–Atbara supplementary package

This repository/deposit contains model equations, reproducible Python scripts, model-ready tables, and validation outputs for the WFAS-v4 formation-level probabilistic analog framework applied to the Shendi–Atbara Basin.

## Repository structure

- `code/`: Python scripts used for WFAS-v4 model runs and validation tests.
- `docs/`: equations, model notes, and manuscript-support text.
- `data_templates/`: lightweight CSV templates and tabulated outputs suitable for Zenodo or journal supplementary files.
- `supplementary_tables/`: integrated Excel workbook for reviewers.

## Core outputs

The current WFAS-v4 run indicates three ranked formation-level petroleum-system outputs:

| Formation | Best analog | WFAS | Mean petroleum probability |
|---|---:|---:|---:|
| Mahmiya Fm | Aradeiba Fm, Muglad | 0.781 | 0.758 |
| Shendi Fm | Bentiu Fm, Muglad | 0.766 | 0.700 |
| Bagrawiya Fm | Abu Gabra Fm, Muglad | 0.712 | 0.686 |

These values are exploratory and should be interpreted together with the uncertainty ranges, validation tests, and geological constraints supplied in the tables.

## Reproducibility

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the scripts in this order where raw rasters/data are available:

1. `shendi_atbara_model_v4_wfas_mc.py`
2. `shendi_atbara_blind_tests_v1.py`
3. `shendi_atbara_validation_suite_v1.py`
4. `shendi_atbara_data_equity_filter_v1.py`
5. `shendi_atbara_additional_validation_v1_FIXED.py`

## Data statement

ASTER and TOPEX-derived layers should be cited to their original providers when deposited. Large raw rasters are not bundled here; only model-ready derived summaries and table outputs are provided.
