
# WFAS-v4 equations

## 1. Formation feature vector

For each formation \(i\), the model defines a standardized geological feature vector:

\[
\mathbf{X}_i = [X_A, X_L, X_D, X_P, X_C, X_S, X_G, X_U, X_Q]
\]

where \(X_A\) is age/chronostratigraphy, \(X_L\) lithology/facies, \(X_D\) depositional environment, \(X_P\) provenance and sediment maturity, \(X_C\) paleoclimate and local climate modifiers, \(X_S\) structural setting, \(X_G\) geophysical/spatial support, \(X_U\) unique basin signature, and \(X_Q\) data quality.

## 2. Weighted formation analog score

For a target formation \(T\) and analog formation \(A\):

\[
WFAS(T,A)=\sum_{k=1}^{K} w_k s_k(T,A)
\]

where \(0 \le s_k \le 1\), \(\sum_k w_k=1\), and \(WFAS\in[0,1]\). WFAS is a similarity score, not a Bayesian probability.

## 3. Spatial support modifier

\[
S_{spatial}=f(I_{FeOx},I_{clay},I_{ferrous},G_{low},G_{grad})
\]

where ASTER-derived mineralogical indices and TOPEX-derived gravity features provide spatial geological constraints.

## 4. Risk aggregation

\[
R_{structural}=\sum_j \alpha_j R_j
\]

where \(R_j\) includes seal risk, leakage risk, timing uncertainty, data-gap risk, and fault-reactivation risk.

## 5. Log-odds petroleum probability

\[
\mathrm{logit}(P_{petroleum}) = \beta_0 + \beta_a WFAS + \beta_s P_{source}+\beta_r P_{reservoir}+\beta_t P_{trap}-\beta_R R_{structural}
\]

\[
P_{petroleum}=\frac{1}{1+e^{-\mathrm{logit}(P_{petroleum})}}
\]

## 6. Monte Carlo uncertainty propagation

For each uncertain input \(z\):

\[
z^{(n)} \sim \mathcal{D}(\mu_z,\sigma_z), \quad n=1,2,\ldots,N
\]

The reported means and credible intervals are computed from the resulting ensemble of \(P_{petroleum}^{(n)}\).
