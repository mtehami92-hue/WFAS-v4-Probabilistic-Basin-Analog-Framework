# Supplementary file manifest

| Material | Content | Recommended platform |
|---|---|---|
| Equations | Full WFAS-v4 mathematical formulation | GitHub + manuscript supplement |
| Code | Python scripts for WFAS, Monte Carlo, validation, and data-equity tests | GitHub |
| Validation tables | Blind tests, sensitivity, ablation, leave-one-basin-out, data-equity, negative controls | Zenodo + manuscript supplement |
| Monte Carlo outputs | Probability distributions and convergence summaries | Zenodo |
| Spatial layers | Derived ASTER/TOPEX model-ready summaries; raw large rasters separately if allowed | Zenodo |
| WFAS weights | Full weighting table and rationale | GitHub + supplement |
| Blind tests | Pre-filled and scored blind-calibration package | Zenodo |
